    <head>
        <meta charset="UTF-8">
        <title>Admin | Dashboard</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- jasny bootstrap -->
        <link href="<?php echo base_url('assets/css/jasny-bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?php echo base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="<?php echo base_url('assets/css/AdminLTE.css') ?>" rel="stylesheet" type="text/css" />
        <!-- Bootstrap WYSIHTML5 -->
        <link href="<?php echo base_url('assets/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- Custom Style -->
        <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo base_url('assets/css/material.min.css') ?>" rel="stylesheet" type="text/css" /> -->
        <!-- Jasny Bootstrap -->
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css">
        <!-- jquery.fancybox.css -->
        <link href="<?php echo base_url('assets/css/jquery.fancybox.css') ?>" rel="stylesheet" type="text/css" />
    </head>