
        <!-- jQuery 2.0.2 -->
        <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="<?php echo base_url('assets/js/jquery-ui-1.10.3.min.js'); ?>" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>" type="text/javascript"></script>
        <!-- Jasny Bootstrap -->
        <script src="<?php echo base_url('assets/js/jasny-bootstrap.min.js') ?>" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url("assets/js/AdminLTE/app.js"); ?>" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="<?php echo base_url("assets/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"); ?>" type="text/javascript"></script>
        <!-- CKEditor -->
        <!--script src="<?php echo base_url("assets/js/plugins/ckeditor/ckeditor.js"); ?>" type="text/javascript"></script -->
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url('assets/js/AdminLTE/demo.js') ?>" type="text/javascript"></script>
        <!-- Angular -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/angular.min.js') ?>"></script>
        <!--script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.8/angular.min.js"></script-->
        <!-- Angular Route -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/angular-route.min.js') ?>"></script>
        <!-- Angular Animate -->
        <!--script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.8/angular-animate.min.js"></script-->
        <!-- Angular Sanitize -->
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/angularjs/1.2.10/angular-sanitize.js"></script>
        <!-- App -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/app.js') ?>"></script>
        <!-- Factory -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/factory.js') ?>"></script>
        <!-- Directives -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/directive.js') ?>"></script>
        <!-- Routes Controller -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/routes.js') ?>"></script>
        <!-- Controllers -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/controllers.js') ?>"></script>
        <!-- Google Maps API -->
        <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&sensor=false"> </script>
        <!--script src="https://maps.googleapis.com/maps/api/js?language=en"> </script-->
        <!-- Maps -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/maps.js') ?>"></script>
        <!-- Jasny Bootstrap -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
        <!-- jquery.fancybox.js -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.js') ?>"></script>
        <!-- Socket IO -->
        <script src="https://cdn.socket.io/socket.io-1.2.1.js"></script>
