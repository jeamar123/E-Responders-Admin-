<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Members
        <small>Add new users</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Members</li>
        <li class="active">Add New Users</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="add-user-form" new-user>

    </div>
</section><!-- /.content -->

