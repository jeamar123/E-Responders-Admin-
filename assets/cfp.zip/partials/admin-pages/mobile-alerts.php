<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Mobile Alerts
        <small>Alerts from mobile users</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Mobile Alerts</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="contentHEre">   
		<div loading-screen>
			<center class="loading-view-container">
				<img src="/Admin-CDO/assets/img/ajax-loader1.gif" ng-show="loading">
			</center>
		</div>
        <div id="directions-panel"></div>
        <div id="new-map-canvas" style="width:100%x;height:480px;"></div>
        <section id="new-map-canvas-script" ng-controller="deptWidURL">
        <script type="text/javascript">
            // Mao ning  para ma focus ang map sa CDO               
            $("#new-map-canvas").ready(function(){
                var marker_start,lat,lng,zoom;
                var directionsDisplay;
                var directionsService = new google.maps.DirectionsService();

                $('#new-map-canvas-script').on('deptID_URL', function(event, data) {
                    $.get( data.url + 'maps/show_focused_map_details/' + data.dept_id , function( response ) {
                        directionsDisplay = new google.maps.DirectionsRenderer();
                        console.log(response)
                        lat = response.lat;
                        lng = response.lng;     
                        zoom = response.zoom;
                        var myCenter = new google.maps.LatLng(lat,lng);
                        var mapProp = {
                            center: myCenter,
                            zoom: parseInt(zoom),
                            mapTypeId: google.maps.MapTypeId.ROADMAP
                        };
                        var map = new google.maps.Map(document.getElementById("new-map-canvas"),mapProp);

                        var marker = new google.maps.Marker({
                              position: myCenter,
                              title:'Click to show information',
                              // icon: data.url + '/assets/img/marker-icon/icon-4.jpg',
                              animation: google.maps.Animation.DROP
                              });

                              animation:
                        marker.setMap(map);
                        // directionsDisplay.setMap(map);
                        // directionsDisplay.setPanel(document.getElementById('directions-panel'));

                        var contentString = '<div id="infowindow" class="scrollFix">'+
                                                '<label style="color: #367FA9">'+response.dept_name+'</label><br>' +
                                                '<span>'+response.address+'<span><br><br>' +
                                                '<a href="http://'+response.website+'" target="__blank"><span>'+response.website+'<span></a><br>' +
                                                '<span>Tel.# :'+response.hotline_no+' | Mobile # :'+response.hotline_no+'<span><br>' +
                                            '</div>';
                        var infowindow = new google.maps.InfoWindow({
                            content: contentString,
                            hideByClick: true
                        });


                        // Mao ning para makuha ang longitude ug latitude
                        google.maps.event.addListener(map, 'click', function( event ){
                            marker.setMap(map);
                        });
                        // I show niya ang infowindow pag ma hover
                        google.maps.event.addListener(marker, 'click', function( event ){
                            infowindow.open(map, this);
                        });
                    }, "json" );        
                });
    

                    // Zoom to 9 when clicking on marker
                // google.maps.event.addListener(marker,'click',function() {
                //    map.setZoom(14);
                //    map.setCenter(marker.getPosition());
                // });
            });            
        </script>
        </section>  
    </div>
</section><!-- /.content -->